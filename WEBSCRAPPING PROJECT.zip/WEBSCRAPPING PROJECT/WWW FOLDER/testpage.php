<html>
  <head>
    <title>Test_Page</title>
  </head>
  <body>
    <h1> TestPage_forIntegrating_PYwithPHP</h1>
    <br><br>
    <form action="testpage.php" method="post">
      <input type="submit" name="submit" value="execute_python">
    </form>
    <?php
    if(isset($_POST["submit"])){
       //echo "ButtonIsClicked";
       system("C:\\Users\\Apeh\\AppData\\Local\\Programs\\Python\\Python310\\python.exe pythonscript.py");
     } 
    ?>
  </body>
</html>


