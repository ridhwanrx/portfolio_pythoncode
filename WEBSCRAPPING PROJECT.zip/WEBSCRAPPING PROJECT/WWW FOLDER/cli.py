# command line arguments

import sys

value1 = int(sys.argv[1])
value2 = int(sys.argv[2])

print("After Addition : ",value1+value2)